"""
Copyright (c) 2019, Oracle Corporation and/or its affiliates.  All rights reserved.
The Universal Permissive License (UPL), Version 1.0
"""

_class_name = 'custom_discoverer'
